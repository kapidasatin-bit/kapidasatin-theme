<?php
/* Template Name: Sepetim */
get_header(); ?>

<div class="cart-page">
    <h1>Sepetim</h1>
    <p>Sepetinizdeki ürünler burada listelenecek.</p>
</div>

<?php get_footer(); ?>
