document.addEventListener('DOMContentLoaded', function() {
  var menuToggle = document.querySelector('.menu-toggle');
  var siteNav = document.querySelector('.site-nav');
  if(menuToggle && siteNav) {
    menuToggle.addEventListener('click', function() {
      siteNav.classList.toggle('active');
    });
  }
  // Mega menu mobilde tıklama ile açılıp kapanma
  var hasMegaMenu = document.querySelector('.has-mega-menu');
  if(window.innerWidth <= 768 && hasMegaMenu) {
    hasMegaMenu.addEventListener('click', function(e) {
      e.preventDefault();
      var megaMenu = hasMegaMenu.querySelector('.mega-menu');
      if(megaMenu) {
        megaMenu.style.display = megaMenu.style.display === 'flex' ? 'none' : 'flex';
      }
    });
  }
  // Footer accordion for mobile
  if(window.innerWidth <= 768) {
    var footerTitles = document.querySelectorAll('.footer-title');
    footerTitles.forEach(function(title) {
      title.addEventListener('click', function() {
        this.classList.toggle('active');
        var list = this.nextElementSibling;
        if(list && list.classList.contains('footer-list')) {
          if(list.style.display === 'block') {
            list.style.display = 'none';
          } else {
            list.style.display = 'block';
          }
        }
      });
    });
  }
});

