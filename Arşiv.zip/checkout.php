<?php
/* Template Name: Ödeme */
get_header(); ?>

<div class="checkout-page">
    <h1>Ödeme</h1>
    <p>Ödeme işlemlerinizi buradan tamamlayabilirsiniz.</p>
</div>

<?php get_footer(); ?>
